# MSGraphConsoleApp
Repo contains some useful demo using microsoft dotnet sdk
